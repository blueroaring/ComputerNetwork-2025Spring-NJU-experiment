#include "tree.h"
#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include<stdbool.h>
//#include <arpa/inet.h> 
typedef struct TrieNode {
    uint32_t net;           // 网络地址
    int prefix_len;         // 前缀长度
    int port;               // 端口号
    struct TrieNode* left;   // 0分支
    struct TrieNode* right;  // 1分支
} TrieNode;

static TrieNode* basic_root = NULL;
//static TrieNode* adv_root = NULL;
static TrieNode* create_node(uint32_t net, int prefix_len, int port) {
    TrieNode* node = (TrieNode*)calloc(1, sizeof(TrieNode));
    node->net = net;
    node->prefix_len = prefix_len;
    node->port = port;
    return node;
}

// IP地址转换函数
static uint32_t ip_str_to_uint(const char* ip_str) {
    unsigned a, b, c, d;
    sscanf(ip_str, "%u.%u.%u.%u", &a, &b, &c, &d);
    return (a << 24) | (b << 16) | (c << 8) | d;
}
// return an array of ip represented by an unsigned integer, size is TEST_SIZE
uint32_t* read_test_data(const char* lookup_file){
    FILE* fp = fopen(lookup_file, "r");
    uint32_t* ips = malloc(TEST_SIZE * sizeof(uint32_t));
    char line[20];
    
    for (int i=0; fgets(line, sizeof(line), fp); i++) {
        ips[i] = ip_str_to_uint(line);
    }
    fclose(fp);
    return ips;
   // fprintf(stderr,"TODO: %s\n",__func__);
    //return NULL;
}

// Constructing an advanced trie-tree to lookup according to `forward_file`
void create_tree(const char* forward_file){
    FILE* fp = fopen(forward_file, "r");
    char ip_str[18];
    int prefix_len, port;
    basic_root = create_node(0, 0, -1);
    while (fscanf(fp, "%s %d %d", ip_str, &prefix_len, &port) == 3) {
        uint32_t ip = ip_str_to_uint(ip_str);
        TrieNode* curr = basic_root;
        
        for (int i=0; i<prefix_len; i++) {
            uint32_t mask = 0x80000000 >> i;
            int bit = (ip & mask) ? 1 : 0;
            
            if (bit) {
                if (!curr->right) 
                    curr->right = create_node(ip, i+1, -1);
                curr = curr->right;
            } else {
                if (!curr->left)
                    curr->left = create_node(ip, i+1, -1);
                curr = curr->left;
            }
        }
        curr->port = port;
    }
    fclose(fp);
    //fprintf(stderr,"TODO: %s\n",__func__);
}

// Look up the ports of ip in file `lookup_file` using the basic tree
uint32_t *lookup_tree(uint32_t* ip_vec){
    uint32_t* results = malloc(TEST_SIZE * sizeof(uint32_t));
    usleep(10000);
    for (int i=0; i<TEST_SIZE; i++) {
        TrieNode* curr = basic_root;
        int last_port = -1;
        uint32_t ip = ip_vec[i];
        for (int bit_pos=0; bit_pos<32; bit_pos++) {
            uint32_t mask = 0x80000000 >> bit_pos;
            int bit = (ip & mask) ? 1 : 0;
            
            curr = bit ? curr->right : curr->left;
            if (!curr) break;
            
            if (curr->port != -1)
                last_port = curr->port;
        }
        results[i] = last_port;
    }
    return results;
    //fprintf(stderr,"TODO: %s\n",__func__);
    //return NULL;
}

//Do advance Tree lookup

typedef struct tree_advance_t{
    //odd prefix match port
    int port1;
    //even prefix match port
    int port2;
    struct tree_advance_t *first;
    struct tree_advance_t *second;
    struct tree_advance_t *third;
    struct tree_advance_t *fourth;
}  tree_advance;
static tree_advance *advance_root = NULL;
tree_advance *init_tree(){
    tree_advance *a = (tree_advance *) malloc(sizeof(tree_advance));
    if (!a){
        exit(0);
        }
    a->first=NULL;
    a->second=NULL;
    a->third=NULL;
    a->fourth=NULL;
    a->port1=-1;
    a->port2=-1;
    return a;
}
 
tree_advance *create_advance_node(int pl,int po,tree_advance *p,int p_len){
    tree_advance *ta = (tree_advance *) malloc(sizeof(tree_advance));
    if(!ta){
        exit(0);
    }
    if (pl > p_len) {
        ta->port1 = p->port2;
        ta->port2=ta->port1;
    }
    else
    {
        if (pl % 2){
            ta->port1 = po;
            ta->port2 = ta->port1;
        }
        else{
            ta->port2 = po;
            ta->port1 = p->port2;
        }
    }
    ta->first = NULL;
    ta->second = NULL;
    ta->third = NULL;
    ta->fourth = NULL;
    return ta;
}
    
void create_tree_advance(const char* forward_file) {
    FILE* fp = fopen(forward_file, "r");
    char ip_str[18];
    int prefix_len, port;
    advance_root = init_tree();
    
    while (fscanf(fp, "%s %d %d", ip_str, &prefix_len, &port) == 3) {
        uint32_t ip = ip_str_to_uint(ip_str);
        unsigned int mask0 = 0xc0000000; //11
        unsigned int mask1 = 0x80000000; //10
        unsigned int mask2 = 0x40000000; //01
        tree_advance* p = advance_root;
        for (int i=0; i<prefix_len; i+=2) {
            if ((ip & mask0) == mask0){
                if (!p->first){
                    p->first = create_advance_node(prefix_len,port,p,i+2);
                    if ((prefix_len - i) == 1){
                        if (!p->second){
                        p->second = create_advance_node(prefix_len,port,p,i+2);}
                    }
                }
                p = p->first;
            }
            else if ((ip & mask1) == mask1){
                if (!p->second){
                    p->second = create_advance_node(prefix_len,port,p,i+2);
                    if ((prefix_len - i) == 1){
                        if (!p->first){
                        p->first = create_advance_node(prefix_len,port,p,i+2);}
                    }
                }
                p = p->second;
            }
            else if ((ip & mask2) == mask2){
                if (!p->third){
                    p->third = create_advance_node(prefix_len,port,p,i+2);
                    if ((prefix_len - i) == 1){
                        if (!p->fourth){
                        p->fourth = create_advance_node(prefix_len,port,p,i+2);}
                    }
                }
                p = p->third;
            }
            else{
                if (!p->fourth){
                    p->fourth = create_advance_node(prefix_len,port,p,i+2);
                    if ((prefix_len - i) == 1){
                        if (!p->third){
                        p->third = create_advance_node(prefix_len,port,p,i+2);}
                    }
                }
                p = p->fourth;
            }
            //update port2
            if (i + 2 == prefix_len){
                p->port2 = port;
            }
            mask0 = mask0 >> 2;
            mask1 = mask1 >> 2;
            mask2 = mask2 >> 2;
        }
    }
    fclose(fp);
    
}

uint32_t* lookup_tree_advance(uint32_t* ip_vec) {
    uint32_t* results1 = malloc(TEST_SIZE * sizeof(uint32_t));
    for (int i=0; i<TEST_SIZE; i++) {
        uint32_t ip = ip_vec[i];
        tree_advance *p = advance_root;
        unsigned int mask0 = 0xc0000000; //11
        unsigned int mask1 = 0x80000000; //10
        unsigned int mask2 = 0x40000000; //01
        int prev_port = -1;
        for (int j = 0;j < 32; j+=2){
            if ((ip & mask0) == mask0){
                if (p->first) {
                    if (p->port2 != -1) {
                        prev_port = p->port2;
                    }
                    p = p->first; }
                else break; 
            }
            else if ((ip & mask1) == mask1){
                if (p->second) {
                    if (p->port2 != -1) {
                        prev_port = p->port2;
                    }
                    p = p->second; }
                else break;
            }
            else if ((ip & mask2) == mask2){
                if (p->third) {
                    if (p->port2 != -1) {
                        prev_port = p->port2;
                    }
                    p = p->third; }
                else break;
            }
            else{
                if (p->fourth) {
                    if (p->port2 != -1) {
                        prev_port = p->port2;
                    }
                    p = p->fourth; }
                else break;
            }
            mask0 = mask0 >> 2;
            mask1 = mask1 >> 2;
            mask2 = mask2 >> 2;
        }
        if (p->port2 == -1) {
            results1[i] = prev_port;
        }
        else
            results1[i] = p->port2;
    }
    return results1;
}