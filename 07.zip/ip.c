#include "ip.h"
#include "icmp.h"
#include "arpcache.h"
#include "rtable.h"
#include "arp.h"

#include "mospf_proto.h"
#include "mospf_daemon.h"

#include "log.h"

#include <stdlib.h>
#include <assert.h>

// handle ip packet
//
// If the packet is ICMP echo request and the destination IP address is equal to
// the IP address of the iface, send ICMP echo reply; otherwise, forward the
// packet.
void handle_ip_packet(iface_info_t *iface, char *packet, int len)
{
	struct iphdr *ip = packet_to_ip_hdr(packet);
	u32 daddr = ntohl(ip->daddr);
	if (daddr == iface->ip) {
		if (ip->protocol == IPPROTO_ICMP) {
			struct icmphdr *icmp = (struct icmphdr *)IP_DATA(ip);
			if (icmp->type == ICMP_ECHOREQUEST) {
				icmp_send_packet(packet, len, ICMP_ECHOREPLY, 0);
			}
		}
		else if (ip->protocol == IPPROTO_MOSPF) {
			handle_mospf_packet(iface, packet, len);
		}

		free(packet);
	}
	else if (ip->daddr == htonl(MOSPF_ALLSPFRouters)) {
		assert(ip->protocol == IPPROTO_MOSPF);
		handle_mospf_packet(iface, packet, len);

		free(packet);
	}
	else {
		ip_forward_packet(daddr, packet, len);
	}
}
// When forwarding the packet, you should check the TTL, update the checksum and TTL.
// Then, determine the next hop to forward the packet, then send the packet by iface_send_packet_by_arp.
// The interface to forward the packet is specified by longest_prefix_match.
void ip_forward_packet(u32 ip_dst, char *packet, int len)
{
	struct iphdr *ip=packet_to_ip_hdr(packet);
	if(--ip->ttl<=0){
		//log(DEBUG,"TTL expired, sending ICMP TIME_EXCEEDED\n");
		rt_entry_t *rt_entry = longest_prefix_match(ntohl(ip->saddr));
        if (rt_entry) {
            // 使用路由器发送ICMP包的接口IP作为源地址
            icmp_send_packet(packet, len, ICMP_TIME_EXCEEDED, ICMP_EXC_TTL);
        }
		free(packet);
		return;
	}

	rt_entry_t *rt_entry=longest_prefix_match(ip_dst);
	if(!rt_entry){
		//log(ERROR,"No route to host " IP_FMT "\n",HOST_IP_FMT_STR(ip_dst));
		icmp_send_packet(packet, len, ICMP_DEST_UNREACH, ICMP_NET_UNREACH);
        free(packet);
        return;
	}
	u32 nxt_hop= rt_entry->gw ? rt_entry->gw : ip_dst;
	//log(DEBUG, "Forwarding packet to IP " IP_FMT " via gateway " IP_FMT,HOST_IP_FMT_STR(ip_dst),HOST_IP_FMT_STR(nxt_hop));
	ip->checksum=ip_checksum(ip);

	//log(DEBUG,"icmp_seq=%u\n",ntohs(ip->id));
	iface_send_packet_by_arp(rt_entry->iface, nxt_hop, packet, len);
	//assert(0 && "TODO: function ip_forward_packet not implemented!");
}
