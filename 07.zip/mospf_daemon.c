#include "mospf_daemon.h"
#include "mospf_nbr.h"
#include "mospf_database.h"
#include "mospf_proto.h"
#include "ip.h"
#include "rtable.h"
#include "list.h"
#include "log.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include<stdbool.h>
extern ustack_t *instance;

pthread_mutex_t mospf_lock;
#define MAX_ROUTERS 256  // 最大路由器数量
static int nodes_sorted[MAX_ROUTERS];  // 存储按最短路径长度排序的节点
static int prev[MAX_ROUTERS]; 
static u32 gw_array[MAX_ROUTERS];            // 存储每个路由器对应的网关
static iface_info_t *rt_if_array[MAX_ROUTERS]; // 存储每个路由器对应的出接口
static u32 int_to_rid[MAX_ROUTERS];    // 整数到路由器ID的映射
static struct list_head rid_int_map[MAX_ROUTERS];   // 路由器ID到整数的映射
static int distances[MAX_ROUTERS];      // 最短距离数组
static int graph[MAX_ROUTERS][MAX_ROUTERS]; // 邻接矩阵
void mospf_init()
{
	pthread_mutex_init(&mospf_lock, NULL);

	instance->area_id = 0;
	// get the ip address of the first interface
	iface_info_t *iface = list_entry(instance->iface_list.next, iface_info_t, list);
	instance->router_id = iface->ip;
	instance->sequence_num = 0;
	instance->lsuint = MOSPF_DEFAULT_LSUINT;

	iface = NULL;
	list_for_each_entry(iface, &instance->iface_list, list) {
		iface->helloint = MOSPF_DEFAULT_HELLOINT;
		init_list_head(&iface->nbr_list);
	}

	init_mospf_db();
	memset(prev, -1, sizeof(prev));
    memset(int_to_rid, 0, sizeof(int_to_rid));
    memset(rid_int_map, 0, sizeof(rid_int_map));
    memset(distances, 0x3f, sizeof(distances)); 
    memset(graph, 0x3f, sizeof(graph));        
}

void *sending_mospf_hello_thread(void *param);
void *sending_mospf_lsu_thread(void *param);
void *checking_nbr_thread(void *param);
void *checking_database_thread(void *param);

void mospf_run()
{
	pthread_t hello, lsu, nbr, db;
	pthread_create(&hello, NULL, sending_mospf_hello_thread, NULL);
	pthread_create(&lsu, NULL, sending_mospf_lsu_thread, NULL);
	pthread_create(&nbr, NULL, checking_nbr_thread, NULL);
	pthread_create(&db, NULL, checking_database_thread, NULL);
}
void send_mospf_hello(iface_info_t *iface){
//    log(DEBUG,"send mospf hello packet in function\n");
	// 计算报文总长度
    int len = ETHER_HDR_SIZE + IP_BASE_HDR_SIZE + MOSPF_HDR_SIZE + MOSPF_HELLO_SIZE;
    char *packet = malloc(len);
  //  log(DEBUG,"ether_header\n");
    // 构造以太网头部
    struct ether_header *eh = (struct ether_header *)packet;
    eh->ether_type = htons(ETH_P_IP);
    memset(eh->ether_dhost, 0xff, ETH_ALEN);  // 广播地址
    memcpy(eh->ether_shost, iface->mac, ETH_ALEN);
  //  log(DEBUG,"ip_header\n");
    // 构造IP头部
    struct iphdr *ip = (struct iphdr *)(packet + ETHER_HDR_SIZE);
    ip_init_hdr(ip, iface->ip, MOSPF_ALLSPFRouters, len - ETHER_HDR_SIZE, IPPROTO_MOSPF);
  //  log(DEBUG,"mospf\n");
    // 构造MOSPF头部
    struct mospf_hdr *mospf = (struct mospf_hdr *)(packet + ETHER_HDR_SIZE + IP_BASE_HDR_SIZE);
    mospf_init_hdr(mospf, MOSPF_TYPE_HELLO, len - ETHER_HDR_SIZE - IP_BASE_HDR_SIZE, 
                   instance->router_id, instance->area_id);
  //  log(DEBUG,"hello\n");
    // 构造Hello消息
    struct mospf_hello *hello = (struct mospf_hello *)((char *)mospf + MOSPF_HDR_SIZE);
    mospf_init_hello(hello, iface->mask);
  //  log(DEBUG,"checksum\n");
    // 计算并设置校验和
    mospf->checksum = mospf_checksum(mospf);
  //  log(DEBUG,"iface_send_packet\n");
    // 发送数据包
    iface_send_packet(iface, packet, len);

	return;
}
void *sending_mospf_hello_thread(void *param)
{
	//fprintf(stdout, "TODO: send mOSPF Hello message periodically.\n");
	  while(1){
		sleep(1);
		pthread_mutex_lock(&mospf_lock);
       // log(DEBUG,"send mospf hello packet periodically.\n");
		iface_info_t *iface;
		list_for_each_entry(iface,&instance->iface_list,list){
			iface->helloint--;
			if(iface->helloint <=0){
                  // log(DEBUG,"send mospf hello packet\n");
                   send_mospf_hello(iface);
                   iface->helloint = MOSPF_DEFAULT_HELLOINT;
			}
		}
		pthread_mutex_unlock(&mospf_lock);
	  }
	 return NULL;
}

/*void *checking_nbr_thread(void *param)
{
	//fprintf(stdout, "TODO: neighbor list timeout operation.\n");
    while (1) {
        sleep(1);
        
        // 创建一个临时链表存储需要删除的邻居
        struct list_head down_nbr_list;
        init_list_head(&down_nbr_list);
        
        pthread_mutex_lock(&mospf_lock);
       // log(DEBUG,"checking neighbor list timeout operation.\n");
        // 遍历所有接口
        iface_info_t *iface;
        list_for_each_entry(iface, &instance->iface_list, list) {
            // 遍历接口的所有邻居
            mospf_nbr_t *nbr, *q;
            list_for_each_entry_safe(nbr, q, &iface->nbr_list, list) {
                nbr->alive++;
                // 如果邻居超时
                if (nbr->alive >= MOSPF_HELLO_TIMEOUT) {
                    // 从接口的邻居列表中移除
                    log(DEBUG,"neighbor timeout, remove it.\n");
                    list_delete_entry(&nbr->list);
                    // 添加到待删除列表
                    list_add_tail(&nbr->list, &down_nbr_list);
                    // 更新邻居数量
                    iface->num_nbr--;
                }
            }
        }
        
        pthread_mutex_unlock(&mospf_lock);

        // 处理待删除的邻居节点
        if (!list_empty(&down_nbr_list)) {
            // 释放所有待删除的邻居节点
            mospf_nbr_t *nbr, *q;
          //  log(DEBUG,"removing down neighbors.\n");
            list_for_each_entry_safe(nbr, q, &down_nbr_list, list) {
                list_delete_entry(&nbr->list);
                free(nbr);
            }
            
            // 由于邻居关系发生变化，需要更新序列号并发送新的LSU
            pthread_mutex_lock(&mospf_lock);
           // log(DEBUG,"neighbor list changed, sending mospf lsu packet.\n");
            instance->sequence_num++;
            send_mospf_lsu();
            pthread_mutex_unlock(&mospf_lock);
        }
    }

    return NULL;
	
}*/
void *checking_nbr_thread(void *param)
{
    while (1) {
        sleep(1);
        
        // 创建临时链表存储要删除的邻居
        struct list_head down_nbr_list;
        init_list_head(&down_nbr_list);
        
        pthread_mutex_lock(&mospf_lock);
        
        // 遍历所有接口
        iface_info_t *iface;
        list_for_each_entry(iface, &instance->iface_list, list) {
            // 遍历每个接口的所有邻居
            mospf_nbr_t *nbr, *q;
            list_for_each_entry_safe(nbr, q, &iface->nbr_list, list) {
                // 如果邻居已经超时
                if (nbr->alive == 0) {
                    // 从接口邻居列表中移除
                    log(DEBUG,"neighbor timeout, remove it.\n");
                    list_delete_entry(&nbr->list);
                    // 添加到待删除列表
                    list_add_tail(&nbr->list, &down_nbr_list);
                    // 更新邻居数量
                    iface->num_nbr--;
                }
                else {
                    // 递减alive计数器
                    nbr->alive--;
                }
            }
        }
        
        pthread_mutex_unlock(&mospf_lock);

        // 如果有需要删除的邻居
        if (!list_empty(&down_nbr_list)) {
            // 释放所有待删除的邻居节点
            mospf_nbr_t *nbr, *q;
            list_for_each_entry_safe(nbr, q, &down_nbr_list, list) {
                list_delete_entry(&nbr->list);
                free(nbr);
            }
            
            // 由于邻居关系发生变化，更新序列号并发送新的LSU
            instance->sequence_num++;
            send_mospf_lsu();
        }
    }
    
    return NULL;
}
void dump_mospf_db_entries(void)
{
    printf("MOSPF Database entries:\n");

    mospf_db_entry_t *db_entry;
    // 遍历数据库中的所有表项
    list_for_each_entry(db_entry, &mospf_db, list) {
        // 对每个表项,遍历其包含的所有LSA
        for (int i = 0; i < db_entry->nadv; i++) {
            struct mospf_lsa *lsa = &db_entry->array[i];
            
            // 按照格式打印:
            // router_id  subnet  mask  neighbor_rid
            fprintf(stdout, 
                "%hhu.%hhu.%hhu.%hhu\t%hhu.%hhu.%hhu.%hhu\t%hhu.%hhu.%hhu.%hhu\t%hhu.%hhu.%hhu.%hhu\n",
                // 打印router_id的4个字节
                (db_entry->rid >> 24) & 0xff,
                (db_entry->rid >> 16) & 0xff, 
                (db_entry->rid >> 8) & 0xff,
                db_entry->rid & 0xff,
                // 打印subnet的4个字节 
                (lsa->network >> 24) & 0xff,
                (lsa->network >> 16) & 0xff,
                (lsa->network >> 8) & 0xff,
                lsa->network & 0xff,
                // 打印mask的4个字节
                (lsa->mask >> 24) & 0xff,
                (lsa->mask >> 16) & 0xff,
                (lsa->mask >> 8) & 0xff,
                lsa->mask & 0xff,
                // 打印neighbor_rid的4个字节
                (lsa->rid >> 24) & 0xff,
                (lsa->rid >> 16) & 0xff,
                (lsa->rid >> 8) & 0xff,
                lsa->rid & 0xff);
        }
    }

    // 刷新输出缓冲区
    fflush(stdout);
}

u8 hash8(char *addr, int len)
{
    u8 hash = 0;
    for (int i = 0; i < len; i++) {
        hash ^= addr[i];
    }
    return hash;
}

void rid_int_map_add(struct list_head *rid_int_map, u32 rid, int *int_id)
{
    // 计算哈希值作为数组索引
    u8 key = hash8((char *)&rid, 4);
    
    // 创建新节点
    struct rid_int *node = malloc(sizeof(struct rid_int));
    memset(node, 0, sizeof(struct rid_int));
    
    // 设置节点数据
    node->rid = rid;
    node->int_id = *int_id;
    (*int_id)++;
    
    // 将节点添加到对应的链表头
    struct list_head *list = &rid_int_map[key];
    list_add_head(&node->list, list);
}

int rid_int_map_lookup(struct list_head *rid_int_map, u32 rid)
{
    // 如果rid为0，直接返回0
    if (rid == 0) {
        return 0;
    }

    // 计算rid的哈希值作为数组索引
    u8 key = hash8((char *)&rid, 4);

    // 遍历对应链表中的所有节点
    struct rid_int *node;
    list_for_each_entry(node, &rid_int_map[key], list) {
        if (node->rid == rid) {
            return node->int_id;  // 找到匹配的rid，返回对应的整数索引
        }
    }

    return -1;  // 未找到匹配的rid
}

int rid_int_map_init(struct list_head *rid_int_map)
{
    // 记录路由器总数
    int num = 0;

    // 初始化所有链表头
    for (int i = 0; i < MAX_ROUTERS; i++) {
        init_list_head(&rid_int_map[i]);
    }

    // 首先添加本路由器的ID
    rid_int_map_add(rid_int_map, instance->router_id, &num);

    // 遍历LSDB
    mospf_db_entry_t *db_entry;
    list_for_each_entry(db_entry, &mospf_db, list) {
        // 添加LSU源路由器的ID
        if (rid_int_map_lookup(rid_int_map, db_entry->rid) == -1) {
            rid_int_map_add(rid_int_map, db_entry->rid, &num);
        }

        // 添加该路由器所有LSA中的邻居路由器ID
        for (int i = 0; i < db_entry->nadv; i++) {
            if (rid_int_map_lookup(rid_int_map, db_entry->array[i].rid) == -1) {
   
				rid_int_map_add(rid_int_map, db_entry->array[i].rid, &num);
            }
        }
    }

    return num;
}

void init_graph(int num)
{
    // 1. 初始化邻接矩阵为0
    for (int i = 0; i < num; i++) {
        memset(graph[i], 0, sizeof(int) * num);
    }

    // 2. 设置当前路由器ID的映射(索引0)
    int_to_rid[0] = instance->router_id;

    // 3. 遍历LSDB构建邻接矩阵
    mospf_db_entry_t *db_entry;
    list_for_each_entry(db_entry, &mospf_db, list) {
        // 获取源路由器的索引
        int src_index = rid_int_map_lookup(rid_int_map, db_entry->rid);
        if (src_index == -1) {
            //log(ERROR, "could not find rid in rid_int map.");
            continue;
        }

        // 记录源路由器ID的映射
        int_to_rid[src_index] = db_entry->rid;

        // 遍历该路由器的所有邻居
        for (int i = 0; i < db_entry->nadv; i++) {
            if (db_entry->array[i].rid != 0) {  // 排除无效邻居
                // 获取目标路由器的索引
                int dst_index = rid_int_map_lookup(rid_int_map, db_entry->array[i].rid);
                
                // 记录目标路由器ID的映射
                int_to_rid[dst_index] = db_entry->array[i].rid;

                // 在邻接矩阵中标记双向连接
                graph[src_index][dst_index] = 1;
                graph[dst_index][src_index] = 1;
            }
        }
    }
}

// 辅助函数：在未访问的节点中找到距离最小的
static int min_dist(int *dist, char *visited, int n) 
{
    int min = 0x7fffffff;
    int min_index = -1;

    for (int i = 0; i < n; i++) {
        if (!visited[i] && dist[i] < min) {
            min = dist[i];
            min_index = i;
        }
    }
    return min_index;
}

// Dijkstra最短路径算法实现
void dijkstra(int num, int src)
{
    // 分配内存
    int *dist = malloc(sizeof(int) * num);       // 存储最短距离
    char *visited = malloc(sizeof(char) * num);   // 标记已访问节点

    // 初始化
    for (int i = 0; i < num; i++) {
        dist[i] = 0x7fffffff;    // 初始化距离为无穷大
        visited[i] = 0;          // 初始化所有节点为未访问
        prev[i] = -1;            // 初始化前驱为-1
    }
    dist[src] = 0;               // 源点到自身的距离为0

    // 对每个节点进行处理
    for (int count = 0; count < num; count++) {
        // 在未访问节点中找距离最小的
        int u = min_dist(dist, visited, num);
        nodes_sorted[count] = u;  // 记录节点的处理顺序
        visited[u] = 1;          // 标记为已访问

        // 更新u的邻接节点的距离
        for (int v = 0; v < num; v++) {
            // 如果v未访问，且u到v有边，且从源点经过u到v的路径更短
            if (!visited[v] && 
                graph[u][v] != 0 && 
                dist[u] != 0x7fffffff &&
                dist[u] + graph[u][v] < dist[v]) 
            {
                dist[v] = dist[u] + graph[u][v];
                prev[v] = u;     // 更新v的前驱为u
            }
        }
    }

    // 释放内存
    free(dist);
    free(visited);
}

// 辅助函数：查找路由器ID对应的IP地址和出接口
static u32 find_rid_ip(u32 rid, iface_info_t **if_out)
{
    iface_info_t *iface;
    list_for_each_entry(iface, &instance->iface_list, list) {
        mospf_nbr_t *nbr;
        list_for_each_entry(nbr, &iface->nbr_list, list) {
            if (nbr->nbr_id == rid) {
                *if_out = iface;
                return nbr->nbr_ip;
            }
        }
    }
    return 0;
}

// 辅助函数：查找rid对应的数据库条目
static mospf_db_entry_t *find_rid_db_entry(u32 rid)
{
    mospf_db_entry_t *db_entry;
    list_for_each_entry(db_entry, &mospf_db, list) {
        if (db_entry->rid == rid) {
            return db_entry;
        }
    }
    return NULL;
}

// 辅助函数：检查目的网络是否已在路由表中
static int dest_in_rtable(struct list_head *routing_table, u32 dest, u32 mask)
{
    rt_entry_t *entry;
    list_for_each_entry(entry, routing_table, list) {
        if (entry->dest == dest && entry->mask == mask) {
            return 1;
        }
    }
    return 0;
}

void convert_path_to_rtable(int num, struct list_head *routing_table)
{
    // 初始化路由表
    init_list_head(routing_table);

    // 先添加直连网络
    iface_info_t *iface;
    list_for_each_entry(iface, &instance->iface_list, list) {
        rt_entry_t *entry = new_rt_entry(
            iface->ip & iface->mask,    // 目的网络
            iface->mask,                // 子网掩码
            0,                          // 直连网络网关为0
            iface                       // 出接口
        );
        list_add_tail(&entry->list, routing_table);
    }

    // 初始化网关和接口数组
    memset(gw_array, 0, sizeof(u32) * num);
    memset(rt_if_array, 0, sizeof(iface_info_t *) * num);

    // 遍历所有路由器(跳过索引0，即当前路由器)
    for (int i = 1; i < num; i++) {
        int curr = nodes_sorted[i];

        // 如果是直接邻居
        if (prev[curr] == 0) {
            // 查找邻居的IP地址和出接口
            gw_array[curr] = find_rid_ip(int_to_rid[curr], &rt_if_array[curr]);
            if (!gw_array[curr]) {
                //log(ERROR, "could not find the ip address for router %x", int_to_rid[curr]);
                continue;
            }
        } 
        // 如果不是直接邻居，继承前驱节点的网关和接口
        else {
            gw_array[curr] = gw_array[prev[curr]];
            rt_if_array[curr] = rt_if_array[prev[curr]];
        }

        // 获取当前路由器的LSA信息
        mospf_db_entry_t *db_entry = find_rid_db_entry(int_to_rid[curr]);
        if (!db_entry) {
            //log(ERROR, "could not find db entry for router %x", int_to_rid[curr]);
            continue;
        }

        // 处理该路由器的所有网络
        for (int j = 0; j < db_entry->nadv; j++) {
            u32 dest = db_entry->array[j].network & db_entry->array[j].mask;
            u32 mask = db_entry->array[j].mask;

            // 如果该网络尚未在路由表中且有有效出接口
            if (!dest_in_rtable(routing_table, dest, mask) && rt_if_array[curr]) {
                rt_entry_t *entry = new_rt_entry(
                    dest,                   // 目的网络
                    mask,                   // 子网掩码
                    gw_array[curr],         // 网关
                    rt_if_array[curr]       // 出接口
                );
                list_add_tail(&entry->list, routing_table);
            }
        }
    }
}
void mospf_dijkstra(struct list_head *routing_table)
{
    // 1. 初始化路由器ID到整数的映射
    int n = rid_int_map_init(rid_int_map);
    //log(DEBUG, "number of routers: %d\n", n);
    // 2. 根据LSDB初始化图结构
    init_graph(n);
    //log(DEBUG, "graph initialized.\n");
    
    // 3. 运行Dijkstra算法，源节点为0(当前路由器)
    dijkstra(n, 0);
   // log(DEBUG, "Dijkstra algorithm completed.\n");
    
    // 4. 打印最短路径的前驱数组
    printf("prev array:\n");
    for (int i = 0; i < n; i++) {
        // 打印当前节点
        printf("%hhu.%hhu.%hhu.%hhu -> ",
            (int_to_rid[i] >> 24) & 0xff,
            (int_to_rid[i] >> 16) & 0xff,
            (int_to_rid[i] >> 8) & 0xff,
            int_to_rid[i] & 0xff);
        
        // 打印前驱节点
        if (prev[i] == -1) {
            printf("-\n");
        } else {
            printf("%hhu.%hhu.%hhu.%hhu\n",
                (int_to_rid[prev[i]] >> 24) & 0xff,
                (int_to_rid[prev[i]] >> 16) & 0xff,
                (int_to_rid[prev[i]] >> 8) & 0xff,
                int_to_rid[prev[i]] & 0xff);
        }
    }
    
    // 5. 将最短路径转换为路由表项
    convert_path_to_rtable(n, routing_table);
    //log(DEBUG, "converted path to routing table.\n");
    // 6. 打印计算得到的路由表
    printf("calculated routing table entries:\n");
    rt_entry_t *rt_entry;
    list_for_each_entry(rt_entry, routing_table, list) {
        printf("%x\t%x\t%x\t%s\n",
            rt_entry->dest,
            rt_entry->mask,
            rt_entry->gw,
            rt_entry->if_name);
    }
}

void mospf_update_rtable(void)
{
    // 1. 用于存储Dijkstra算法计算出的路由表项
    struct list_head routing_table;
    init_list_head(&routing_table);

    // 2. 运行Dijkstra算法计算最短路径
    mospf_dijkstra(&routing_table);

    // 3. 清除当前路由表
    clear_rtable();

    // 4. 加载新的路由表
    load_rtable(&routing_table);
    //log(DEBUG, "loaded new routing table.\n");
}



void *checking_database_thread(void *param)
{
    while (1) {
        sleep(1);
        pthread_mutex_lock(&mospf_lock);
        
        // 标记是否发生变化
        bool changed = false;
        
        // 安全遍历链表
        mospf_db_entry_t *db = (mospf_db_entry_t *)mospf_db.next;
        mospf_db_entry_t *q = (mospf_db_entry_t *)(mospf_db.next)->next;
        
        while (db != (mospf_db_entry_t *)&mospf_db) {
            // 递减存活时间
            db->alive--;
            
            // 检查是否超时
            if (db->alive < 1) {
                // 删除超时条目
                list_delete_entry(&db->list);
                free(db->array);
                free(db);
                changed = true;
            }
            
            // 移动到下一个条目
            db = q;
            q = (mospf_db_entry_t *)(q->list).next;
        }
        
        // 如果有条目被删除，更新数据库和路由表
        if (changed) {
            dump_mospf_db_entries();
            mospf_update_rtable();
        }
        
        pthread_mutex_unlock(&mospf_lock);
    }
    
    return NULL;
}
void update_nbr_list_via_hello(iface_info_t *iface, u32 rid, u32 ip, u32 mask, int helloint)
{
    pthread_mutex_lock(&mospf_lock);

    // 先查找是否已存在该邻居
    mospf_nbr_t *nbr;
    list_for_each_entry(nbr, &iface->nbr_list, list) {
        if (rid == nbr->nbr_id && ip == nbr->nbr_ip) {
            // 已存在则更新alive时间
            nbr->alive = helloint * 3;
            pthread_mutex_unlock(&mospf_lock);
            return;
        }
    }

    // 检查掩码是否匹配
    if (mask != iface->mask) {
        if (this_log_level < ERROR) {
            fprintf(stderr, 
                "%s: received mospf hello with mask (0x%x) not equal to iface->mask (0x%x)\n",
                log_level_str[ERROR], mask, iface->mask);
        }
        pthread_mutex_unlock(&mospf_lock);
        return;
    }

    // 检查子网是否匹配
    if ((ip & mask) != (iface->ip & iface->mask)) {
        if (this_log_level < ERROR) {
            fprintf(stderr,
                "%s: received mospf hello with subnet (0x%x) not equal to iface->subnet (0x%x)\n",
                log_level_str[ERROR], ip & mask, iface->ip & iface->mask);
        }
        pthread_mutex_unlock(&mospf_lock);
        return;
    }

    // 创建新邻居
    mospf_nbr_t *new_nbr = malloc(sizeof(mospf_nbr_t));
    new_nbr->nbr_id = rid;
    new_nbr->nbr_ip = ip;
    new_nbr->nbr_mask = mask;
    new_nbr->alive = helloint * 3;
    
    // 添加到邻居列表
    list_add_tail(&new_nbr->list, &iface->nbr_list);
    iface->num_nbr++;

    // 更新序列号并发送LSU
    instance->sequence_num++;
    if (this_log_level == DEBUG) {
        fprintf(stderr, "%s: received new mospf hello, update nbr list\n",
                log_level_str[DEBUG]);
    }
    send_mospf_lsu();

    pthread_mutex_unlock(&mospf_lock);
}
void handle_mospf_hello(iface_info_t *iface, char *packet, int len)
{
    struct iphdr *ip = packet_to_ip_hdr(packet);
    struct mospf_hdr *mospf = (struct mospf_hdr *)((char *)ip + IP_HDR_SIZE(ip));
    struct mospf_hello *hello = (struct mospf_hello *)((char *)mospf + MOSPF_HDR_SIZE);
    
    // 获取发送方的IP地址
    u32 src_ip = ntohl(ip->saddr);
    if (src_ip != iface->ip) {
        // 校验检验和
        if (mospf->checksum != mospf_checksum(mospf)) {
            if (this_log_level < ERROR) {
                fprintf(stderr, "%s: received mospf hello packet, with invalid checksum.\n",
                        log_level_str[ERROR]);
            }
            return;
        }

        // 检查子网掩码是否匹配
        u32 nbr_mask = ntohl(hello->mask);
        if (nbr_mask != iface->mask) {
            if (this_log_level < ERROR) {
                fprintf(stderr, 
                    "%s: received mospf hello packet, with unmatched mask (%x vs %x).\n",
                    log_level_str[ERROR], nbr_mask, iface->mask);
            }
            return;
        }

        // 检查hello间隔是否为5
        u16 hello_int = ntohs(hello->helloint);
        if (hello_int == MOSPF_DEFAULT_HELLOINT) {
            u32 nbr_id = ntohl(mospf->rid);
            update_nbr_list_via_hello(iface, nbr_id, src_ip, nbr_mask, hello_int);
        }
        else if (this_log_level < ERROR) {
            fprintf(stderr, "%s: received mospf hello packet, with invalid helloint.\n",
                    log_level_str[ERROR]);
        }
    }
}

/*// 生成MOSPF LSU消息的辅助函数
char *generate_mospf_lsu(int *len)
{
    pthread_mutex_lock(&mospf_lock);
    
    // 计算所有邻居数量
    u32 nadv = 0;
    iface_info_t *iface;
    
    // 计算本地接口的LSA数量
    list_for_each_entry(iface, &instance->iface_list, list) {
        if (iface->num_nbr == 0) {
            nadv++; // 没有邻居的接口也算一个
        } else {
            nadv += iface->num_nbr; // 加上该接口的所有邻居
        }
    }

    // 计算数据库中的LSA数量
    mospf_db_entry_t *db_entry;
    list_for_each_entry(db_entry, &mospf_db, list) {
        nadv += db_entry->nadv;  // 加上数据库中每个条目的LSA数量
    }

    // 计算消息总长度
    *len = MOSPF_HDR_SIZE + MOSPF_LSU_SIZE + nadv * MOSPF_LSA_SIZE;
    
    // 分配内存
    char *buffer = malloc(*len);
    if (!buffer) {
        pthread_mutex_unlock(&mospf_lock);
        return NULL;
    }

    struct mospf_hdr *mospf = (struct mospf_hdr *)buffer;
    struct mospf_lsu *lsu = (struct mospf_lsu *)((char *)mospf + MOSPF_HDR_SIZE);
    struct mospf_lsa *lsa = (struct mospf_lsa *)((char *)lsu + MOSPF_LSU_SIZE);

    // 初始化MOSPF头部
    mospf_init_hdr(mospf, MOSPF_TYPE_LSU, *len, instance->router_id, instance->area_id);
    
    // 初始化LSU头部
    mospf_init_lsu(lsu, nadv);

    // 首先填充本地接口的LSA条目
    list_for_each_entry(iface, &instance->iface_list, list) {
        if (iface->num_nbr == 0) {
            // 没有邻居的接口,添加一个空条目
            lsa->network = htonl(iface->ip & iface->mask);
            lsa->mask = htonl(iface->mask);
            lsa->rid = 0;
            lsa++;
        } else {
            // 遍历该接口的所有邻居
            mospf_nbr_t *nbr;
            list_for_each_entry(nbr, &iface->nbr_list, list) {
                lsa->network = htonl(iface->ip & iface->mask);
                lsa->mask = htonl(iface->mask);
                lsa->rid = htonl(nbr->nbr_id);
                lsa++;
            }
        }
    }

    // 然后填充数据库中的LSA条目
    list_for_each_entry(db_entry, &mospf_db, list) {
        for (int i = 0; i < db_entry->nadv; i++) {
            lsa->network = htonl(db_entry->array[i].network);
            lsa->mask = htonl(db_entry->array[i].mask);
            lsa->rid = htonl(db_entry->array[i].rid);
            lsa++;
        }
    }

    // 计算校验和
    mospf->checksum = mospf_checksum(mospf);

    pthread_mutex_unlock(&mospf_lock);
    return buffer;
}*/
// 生成MOSPF LSU消息的辅助函数
char *generate_mospf_lsu(int *len)
{
    // 计算所有邻居数量
    //log(DEBUG, "Generating mOSPF LSU message\n");
    u32 nadv = 0;
    iface_info_t *iface;
    list_for_each_entry(iface, &instance->iface_list, list) {
        if (iface->num_nbr == 0) {
            nadv++; // 没有邻居的接口也算一个
        } else {
            nadv += iface->num_nbr;
        }
    }
    // 计算消息总长度
    *len = MOSPF_HDR_SIZE + MOSPF_LSU_SIZE + nadv * MOSPF_LSA_SIZE;
    
    // 分配内存
    char *buffer = malloc(*len);
    struct mospf_hdr *mospf = (struct mospf_hdr *)buffer;
    struct mospf_lsu *lsu = (struct mospf_lsu *)((char *)mospf + MOSPF_HDR_SIZE);
    struct mospf_lsa *lsa = (struct mospf_lsa *)((char *)lsu + MOSPF_LSU_SIZE);

    // 初始化MOSPF头部
    mospf_init_hdr(mospf, MOSPF_TYPE_LSU, *len, instance->router_id, instance->area_id);
    
    // 初始化LSU头部
    mospf_init_lsu(lsu, nadv);

    // 填充LSA条目
    list_for_each_entry(iface, &instance->iface_list, list) {
        if (iface->num_nbr == 0) {
            // 没有邻居的接口,添加一个空条目
            lsa->network = htonl(iface->ip & iface->mask);
            lsa->mask = htonl(iface->mask);
            lsa->rid = 0;
            lsa++;
        } else {
            // 遍历该接口的所有邻居
            mospf_nbr_t *nbr;
            list_for_each_entry(nbr, &iface->nbr_list, list) {
                lsa->network = htonl(nbr->nbr_ip & nbr->nbr_mask);
                lsa->mask = htonl(nbr->nbr_mask);
                lsa->rid = htonl(nbr->nbr_id);
                lsa++;
            }
        }
    }
    // 计算校验和
    mospf->checksum = mospf_checksum(mospf);

    return buffer;
}
// 发送MOSPF LSU消息
void send_mospf_lsu(void)
{
    // 生成LSU消息
    int mospf_len;
    char *mospf_msg = generate_mospf_lsu(&mospf_len);
    if (!mospf_msg) {
       // log(ERROR, "Failed to generate LSU message");
        return;
    }
   // log(DEBUG, "Generated LSU message of length %d\n", mospf_len);
    // 遍历所有接口发送LSU
    iface_info_t *iface;
    list_for_each_entry(iface, &instance->iface_list, list) {
        // 遍历该接口的所有邻居
        mospf_nbr_t *nbr;
        list_for_each_entry(nbr, &iface->nbr_list, list) {
            // 计算数据包总长度
            int pkt_len = ETHER_HDR_SIZE + IP_BASE_HDR_SIZE + mospf_len;
            char *packet = malloc(pkt_len);
            if (!packet) {
               // log(ERROR, "Failed to allocate memory for LSU packet");
                continue;
            }
            // 初始化以太网头部
          struct ether_header *eh = (struct ether_header *)packet;
          eh->ether_type = htons(ETH_P_IP);
         memcpy(eh->ether_shost, iface->mac, ETH_ALEN);
          // 设置目的MAC为广播地址
          memset(eh->ether_dhost, 0xff, ETH_ALEN);
            // 复制MOSPF消息到IP负载部分
            memcpy(packet + ETHER_HDR_SIZE + IP_BASE_HDR_SIZE, 
                   mospf_msg, mospf_len);

            // 初始化IP头
            struct iphdr *ip = packet_to_ip_hdr(packet);
            ip_init_hdr(ip, iface->ip, nbr->nbr_ip, 
                       pkt_len - ETHER_HDR_SIZE, IPPROTO_MOSPF);

            // 发送数据包
            ip_send_packet(packet, pkt_len);

           // log(DEBUG, "Sent LSU to neighbor %x via interface %s", 
              //  nbr->nbr_ip, iface->name);
        }
    }

    // 释放LSU消息缓冲区
    free(mospf_msg);
}
void *sending_mospf_lsu_thread(void *param)
{
	//fprintf(stdout, "TODO: send mOSPF LSU message periodically.\n");
   
	while(1){
	sleep(1);
	pthread_mutex_lock(&mospf_lock);
   // log(DEBUG,"send mospf lsu packet periodically.\n");
	instance->lsuint--;
	if (instance->lsuint <= 0) {
		// 发送LSU报文
       // log(DEBUG,"send mospf lsu packet to all neighbors\n");
		send_mospf_lsu();
		// 更新序列号
		instance->sequence_num++;
		// 重置计时器
		instance->lsuint = MOSPF_DEFAULT_LSUINT;
	}
	pthread_mutex_unlock(&mospf_lock);
}
	return NULL;
}
// 更新MOSPF数据库
void update_mospf_db_via_lsu(mospf_db_entry_t *db_entry, iface_info_t *iface, 
    u32 rid, struct mospf_lsu *lsu)
{
u16 seq = ntohs(lsu->seq);
u32 nadv = ntohl(lsu->nadv);

if (!db_entry) {
// 创建新条目
db_entry = malloc(sizeof(mospf_db_entry_t));
init_list_head(&db_entry->list);
db_entry->rid = rid;
db_entry->seq = seq;
db_entry->alive = MOSPF_DATABASE_TIMEOUT;
db_entry->nadv = nadv;
db_entry->array = copy_lsa_ntoh((struct mospf_lsa *)(lsu + 1), nadv);
list_add_tail(&db_entry->list, &mospf_db);
} else {
// 更新现有条目
if (db_entry->array) {
free(db_entry->array);
}
db_entry->seq = seq;
db_entry->alive = MOSPF_DATABASE_TIMEOUT;
db_entry->nadv = nadv;
db_entry->array = copy_lsa_ntoh((struct mospf_lsa *)(lsu + 1), nadv);
}

dump_mospf_db_entries();
}

// 复制并转换LSA数组（网络字节序到主机字节序）
struct mospf_lsa *copy_lsa_ntoh(struct mospf_lsa *array, int nadv)
{
struct mospf_lsa *new_array = malloc(nadv * sizeof(struct mospf_lsa));

for (int i = 0; i < nadv; i++) {
new_array[i].network = ntohl(array[i].network);
new_array[i].mask = ntohl(array[i].mask);
new_array[i].rid = ntohl(array[i].rid);
}

return new_array;
}
void forward_mospf_lsu(iface_info_t *iface, char *packet, int len)
{
    // 获取IP头部
    struct iphdr *ip = packet_to_ip_hdr(packet);
    // 获取MOSPF头部
    struct mospf_hdr *mospf = (struct mospf_hdr *)((char *)ip + IP_HDR_SIZE(ip));
    struct mospf_lsu *lsu = (struct mospf_lsu *)((char *)mospf + MOSPF_HDR_SIZE);

    // 检查TTL
    if (lsu->ttl <= 0) {
        return;
    }

    // 遍历所有接口
    iface_info_t *tx_iface;
    list_for_each_entry(tx_iface, &instance->iface_list, list) {
        // 跳过接收接口
        if (tx_iface->index == iface->index) {
            continue;
        }

        // 遍历该接口的所有邻居
        mospf_nbr_t *nbr;
        list_for_each_entry(nbr, &tx_iface->nbr_list, list) {
            // 为每个邻居创建一个新的数据包副本
            char *new_packet = malloc(len);
            if (!new_packet) {
              //  log(ERROR, "Failed to allocate memory for LSU packet");
                continue;
            }
            memcpy(new_packet, packet, len);

            // 更新以太网头部
            struct ether_header *eh = (struct ether_header *)new_packet;
            memcpy(eh->ether_shost, tx_iface->mac, ETH_ALEN);
            memset(eh->ether_dhost, 0xff, ETH_ALEN);  // 广播地址

            // 更新IP头部
            struct iphdr *new_ip = packet_to_ip_hdr(new_packet);
            new_ip->saddr = htonl(tx_iface->ip);
            new_ip->daddr = htonl(nbr->nbr_ip);
            new_ip->checksum = ip_checksum(new_ip);

            if (this_log_level == DEBUG) {
                fprintf(stderr, "%s: forward mospf lsu packet, send from %x to %x\n",
                        log_level_str[0], tx_iface->ip, nbr->nbr_ip);
            }

            // 发送数据包
            ip_send_packet(new_packet, len);
        }
    }
}
mospf_db_entry_t *find_mospf_db_entry(iface_info_t *iface, u32 rid)
{
    // 遍历MOSPF数据库中的所有条目
    mospf_db_entry_t *db_entry;
    list_for_each_entry(db_entry, &mospf_db, list) {
        // 如果找到匹配的router ID，返回该条目
        if (db_entry->rid == rid) {
            return db_entry;
        }
    }
    
    // 未找到匹配条目，返回NULL
    return NULL;
}
void handle_mospf_lsu(iface_info_t *iface, char *packet, int len)
{
    // 获取 LSU 消息头
    struct iphdr *ip = packet_to_ip_hdr(packet);
    struct mospf_hdr *mospf = (struct mospf_hdr *)((char *)ip + IP_HDR_SIZE(ip));
    struct mospf_lsu *lsu = (struct mospf_lsu *)((char *)mospf + MOSPF_HDR_SIZE);

    // 调试日志
    if (this_log_level == DEBUG) {
        u32 src_rid = ntohl(mospf->rid);
        fprintf(stderr, "%s: [%s:%s] received mospf lsu, from router [%x]\n",
                log_level_str[0], iface->name, iface->ip_str, src_rid);
    }

    // 校验检验和
    if (mospf->checksum != mospf_checksum(mospf)) {
        if (this_log_level < ERROR) {
            fprintf(stderr, "%s: received mospf lsu packet, with invalid checksum.\n",
                    log_level_str[ERROR]);
        }
        return;
    }

    // 获取发送方的router id
    u32 rid = ntohl(mospf->rid);
    
    // 如果LSU来自自己，直接忽略
    if (rid == instance->router_id) {
        return;
    }

    // 获取序列号
    u16 seq = ntohs(lsu->seq);
    
    // 在数据库中查找此路由器的条目
    mospf_db_entry_t *db_entry = find_mospf_db_entry(iface, rid);

    // 检查是否需要更新数据库
    // if (!db_entry || seq > db_entry->seq) {
        // 打印调试信息
        if (this_log_level == DEBUG) {
            fprintf(stderr, 
                "%s: received new mospf lsu packet, with %d lsa from %hhu.%hhu.%hhu.%hhu.\n",
                log_level_str[0], ntohl(lsu->nadv),
                (rid >> 24) & 0xff, (rid >> 16) & 0xff,
                (rid >> 8) & 0xff, rid & 0xff);
        }

        // 更新数据库
        update_mospf_db_via_lsu(db_entry, iface, rid, lsu);

        // 减少TTL并转发
        lsu->ttl--;
        mospf->checksum = mospf_checksum(mospf);
        
        if (lsu->ttl > 0) {
            forward_mospf_lsu(iface, packet, len);
        }

        // 更新路由表
        mospf_update_rtable();
    //}
   // else if (this_log_level == DEBUG) {
    //   fprintf(stderr, "%s: has received this mospf lsu message before, ignore it\n",
   //            log_level_str[0]);
    //}
}

void handle_mospf_packet(iface_info_t *iface, char *packet, int len)
{
	struct iphdr *ip = (struct iphdr *)(packet + ETHER_HDR_SIZE);
	struct mospf_hdr *mospf = (struct mospf_hdr *)((char *)ip + IP_HDR_SIZE(ip));

	if (mospf->version != MOSPF_VERSION) {
		log(ERROR, "received mospf packet with incorrect version (%d)", mospf->version);
		return ;
	}
	if (mospf->checksum != mospf_checksum(mospf)) {
		log(ERROR, "received mospf packet with incorrect checksum");
		return ;
	}
	if (ntohl(mospf->aid) != instance->area_id) {
		log(ERROR, "received mospf packet with incorrect area id");
		return ;
	}

	switch (mospf->type) {
		case MOSPF_TYPE_HELLO:
            log(DEBUG, "Received mOSPF Hello packet\n");
			handle_mospf_hello(iface, packet, len);
			break;
		case MOSPF_TYPE_LSU:
            log(DEBUG,"Received mOSPF LSU packet\n");
			handle_mospf_lsu(iface, packet, len);
			break;
		default:
			log(ERROR, "received mospf packet with unknown type (%d).", mospf->type);
			break;
	}
}