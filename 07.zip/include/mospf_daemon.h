#ifndef __MOSPF_DAEMON_H__
#define __MOSPF_DAEMON_H__

#include "base.h"
#include "types.h"
#include "list.h"

void mospf_init();
void mospf_run();
void handle_mospf_packet(iface_info_t *iface, char *packet, int len);
struct mospf_lsa *copy_lsa_ntoh(struct mospf_lsa *array, int nadv);
struct rid_int{
    struct list_head list;
    u32 rid;
    int int_id;
};
#endif
