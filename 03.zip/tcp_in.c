#include "tcp.h"
#include "tcp_sock.h"
#include "tcp_timer.h"

#include "log.h"
#include "ring_buffer.h"

#include <stdlib.h>
// 检查发送窗口是否有足够空间发送一个MSS大小的报文
int tcp_tx_window_test(struct tcp_sock *tsk)
{
   // log(DEBUG,"snd_nxt=%u snd_una=%u snd_wnd=%u",tsk->snd_nxt,tsk->snd_una,tsk->snd_wnd);
    // 计算已发送但未确认的数据量
    u32 bytes_in_flight;
    if (less_than_32b(tsk->snd_una, tsk->snd_nxt)) {
        bytes_in_flight = tsk->snd_nxt - tsk->snd_una;
    } else {
        bytes_in_flight = 0;
    }
    
    // 计算剩余可用窗口大小
    u32 available_window = tsk->snd_wnd - bytes_in_flight;
    return (available_window >= TCP_MSS);
}
// update the snd_wnd of tcp_sock
//
// if the snd_wnd before updating is zero, notify tcp_sock_send (wait_send)
static inline void tcp_update_window(struct tcp_sock *tsk, struct tcp_cb *cb)
{
	/*u16 old_snd_wnd = tsk->snd_wnd;
	tsk->snd_wnd = cb->rwnd;
	if (old_snd_wnd == 0)
		wake_up(tsk->wait_send);*/
        
    
        // 1. 记录更新前的窗口状态
        int had_window = tcp_tx_window_test(tsk);
        
        // 2. 更新相关参数
        tsk->snd_una = cb->ack;        // 更新已确认序号
        tsk->adv_wnd = cb->rwnd;       // 更新对端通告窗口
        tsk->cwnd = 0x7f7f7f7f;        // 设置较大的拥塞窗口
        tsk->snd_wnd = min(tsk->adv_wnd, tsk->cwnd); // 发送窗口取两者最小值
        
        // 3. 检查更新后的窗口状态
        int has_window = tcp_tx_window_test(tsk);
        if (tsk->snd_wnd < TCP_MSS) {
            log(DEBUG,"snd_wnd < TCP_MSS");
            tcp_set_persist_timer(tsk);
        } else {
            tcp_unset_persist_timer(tsk);
        }
        // 4. 如果原本没有足够窗口,现在有了,则唤醒发送
        if (!had_window && has_window){
           // log(DEBUG,"has_window ");
            wake_up(tsk->wait_send);
        }
       
}

// update the snd_wnd safely: cb->ack should be between snd_una and snd_nxt
static inline void tcp_update_window_safe(struct tcp_sock *tsk, struct tcp_cb *cb)
{
	if (less_or_equal_32b(tsk->snd_una, cb->ack) && less_or_equal_32b(cb->ack, tsk->snd_nxt))
		tcp_update_window(tsk, cb);
}

#ifndef max
#	define max(x,y) ((x)>(y) ? (x) : (y))
#endif

// check whether the sequence number of the incoming packet is in the receiving
// window
static inline int is_tcp_seq_valid(struct tcp_sock *tsk, struct tcp_cb *cb)
{
	u32 rcv_end = tsk->rcv_nxt + max(tsk->rcv_wnd, 1);
	if (less_than_32b(cb->seq, rcv_end) && less_or_equal_32b(tsk->rcv_nxt, cb->seq_end)) {
		return 1;
	}
	else {
		log(ERROR, "received packet with invalid seq, drop it.");
        log(DEBUG,"less_than_32b(cb->seq,rcv_end)=%d",less_than_32b(cb->seq,rcv_end));
        log(DEBUG,"less_or_equal_32b(tsk->rcv_nxt,cb->seq_end)=%d",less_or_equal_32b(tsk->rcv_nxt,cb->seq_end));
		return 0;
	}
}

// Process the incoming packet according to TCP state machine. 
void tcp_process(struct tcp_sock *tsk, struct tcp_cb *cb, char *packet)
{
    //log(DEBUG,"process_lockstart");
    pthread_mutex_lock(&tsk->sk_lock);
    //log(DEBUG,"process_locksuccess");
    //assert(0);
	//fprintf(stdout, "TODO: implement %s please.\n", __FUNCTION__);
    /*if (!tsk) {
        if (cb->flags & TCP_RST) {
            pthread_mutex_unlock(&tsk->sk_lock);
            return;
        }
        if (cb->flags & TCP_ACK) {
            
            tcp_send_reset(cb);
            pthread_mutex_unlock(&tsk->sk_lock);
            return;
        }
        if (cb->flags & TCP_SYN) {
            struct tcp_sock *csk = alloc_tcp_sock();
            csk->sk_sip = cb->daddr;
            csk->sk_sport = cb->dport;
            csk->sk_dip = cb->saddr;
            csk->sk_dport = cb->sport;
            csk->parent = tsk;
            tcp_set_state(csk, TCP_SYN_RECV);
            tcp_hash(csk);
            tcp_send_control_packet(csk, TCP_SYN | TCP_ACK);
            pthread_mutex_unlock(&tsk->sk_lock);
            return;
        }
    }*/
     // 验证序列号
     

    // 如果是数据包,写入接收缓冲区
    if (cb->pl_len > 0) {
      //  printf("rcv_nxt=%u, seq=%u, seq_end=%u\n", tsk->rcv_nxt, cb->seq, cb->seq_end);
       /* if(tsk->rcv_nxt<cb->seq){
            printf("rcv_nxt<seq\n");
            pthread_mutex_unlock(&tsk->sk_lock);
            tcp_send_control_packet(tsk, TCP_ACK);
            return;
        }
        if (!is_tcp_seq_valid(tsk, cb)) {
            pthread_mutex_unlock(&tsk->sk_lock);
            printf("invalid\n");
            tcp_send_control_packet(tsk, TCP_ACK);
            return;
        }
        pthread_mutex_lock(&tsk->rcv_buf_lock);
        
        // 写入接收缓冲区
        write_ring_buffer(tsk->rcv_buf, cb->payload, cb->pl_len);
        // 更新期望接收的下一个序号
        tsk->rcv_nxt = cb->seq_end;
        // 更新接收窗口
       // tsk->rcv_wnd = ring_buffer_free(tsk->rcv_buf);
        
        
        
        // 发送累积ACK
        pthread_mutex_unlock(&tsk->rcv_buf_lock);
       // pthread_mutex_lock(&tsk->send_buf_lock);
        tcp_send_control_packet(tsk, TCP_ACK);
       // pthread_mutex_unlock(&tsk->send_buf_lock);
        wake_up(tsk->wait_recv);*/
       // tsk->rcv_nxt = cb->seq_end;
       
        tcp_recv_ofo_buffer_add_packet(tsk, cb);
       // tsk->rcv_nxt = cb->seq_end;
        // 发送累积ACK
        tcp_send_control_packet(tsk, TCP_ACK);
        wake_up(tsk->wait_recv);
    }
    else{
    switch (tsk->state) {
        case TCP_LISTEN:
            if (cb->flags & TCP_SYN) {
                
                
                tsk->sk_sip = cb->daddr;
                tsk->sk_sport = cb->dport;
                tsk->sk_dip = cb->saddr;
                tsk->sk_dport = cb->sport;
                tsk->parent = tsk;
                tsk->iss = tcp_new_iss();
                tsk->snd_nxt = tsk->iss;
                tsk->snd_una = tsk->iss;

                // 设置接收下一个序列号
                tsk->rcv_nxt = cb->seq_end;
                tcp_set_state(tsk, TCP_SYN_RECV);
                tcp_hash(tsk);
              //  log(DEBUG,"get SYN");
                tcp_send_control_packet(tsk, TCP_SYN | TCP_ACK);
                tcp_sock_accept_enqueue(tsk);
                wake_up(tsk->wait_accept);
            }
            break;
        case TCP_SYN_SENT:
           // log(DEBUG,"SYN_SENT");
            if (cb->flags & (TCP_SYN|TCP_ACK)) {
               
               // if (cb->ack == tsk->snd_nxt) {
                    // 更新接收序号：对方的序号+1(SYN占一个序号)
                   tsk->rcv_nxt = cb->seq+1;
                    
                    // 更新发送序号
                    tcp_update_send_buffer(tsk, cb->ack);
                   // tsk->snd_una = cb->ack;  // 确认收到了我们的SYN
                     
                    
                    // 更新窗口等参数
                    tcp_unset_retrans_timer(tsk);
                    tcp_update_window_safe(tsk, cb);
                    tsk->snd_nxt = tsk->snd_una;  // 下一个发送序号
                    // 切换状态并发送ACK
                    tcp_set_state(tsk, TCP_ESTABLISHED);
                    tcp_send_control_packet(tsk, TCP_ACK);
                    
                    wake_up(tsk->wait_connect);
               // }
                
            }
            break;
        case TCP_SYN_RECV:
          // log(DEBUG,"SYN_RECV");
            if (cb->flags & TCP_ACK) {
               // tsk->snd_una = cb->ack;
               tsk->rcv_nxt = cb->seq_end;
                tcp_update_window_safe(tsk, cb);
                tcp_unset_retrans_timer(tsk);
                    tcp_set_state(tsk, TCP_ESTABLISHED);
                    wake_up(tsk->wait_connect);
            }
            break;
        case TCP_ESTABLISHED:
           // log(DEBUG,"ESTABLISHED1");
            if (cb->flags & TCP_FIN) {//server收到FIN包
              //  printf("ESTABLISHEDFIN");
                tsk->rcv_nxt = cb->seq_end;
                tcp_set_state(tsk, TCP_CLOSE_WAIT);
                if (ring_buffer_empty(tsk->rcv_buf)) {
                    // 没有待发送数据，直接发送 FIN 包，进入 TCP_LAST_ACK 状态
                    tcp_send_control_packet(tsk, TCP_ACK | TCP_FIN);
                    tcp_set_state(tsk, TCP_LAST_ACK);}
                    else {
                        // 有待发送数据，先发送 ACK 包，等待数据传输完毕再发送 FIN 包
                        tcp_send_control_packet(tsk, TCP_ACK);
                        sleep_on(tsk->wait_send);//to be changed
                        tcp_send_control_packet(tsk, TCP_FIN);
                        tcp_set_state(tsk, TCP_LAST_ACK);
                    }
                wake_up(tsk->wait_recv);
            } else if ((cb->flags & TCP_ACK)&&cb->pl_len==0) {
                // printf("established_ack\n");
                //tsk->snd_una = cb->ack;
                tcp_update_send_buffer(tsk, cb->ack);
                tcp_update_retrans_timer(tsk);
                tcp_update_window_safe(tsk, cb);
                wake_up(tsk->wait_send);
            }
            break;
        case TCP_LAST_ACK:
            if (cb->flags & TCP_ACK) {
               // tsk->snd_una = cb->ack;
               tsk->rcv_nxt = cb->seq_end;
               tcp_update_send_buffer(tsk, cb->ack);
                   // tcp_unset_retrans_timer(tsk);
                tcp_update_window_safe(tsk, cb);
                tcp_set_state(tsk, TCP_CLOSED);
                wake_up(tsk->wait_send);
            }
            break;
        case TCP_FIN_WAIT_1:
            if (cb->flags & TCP_ACK&&!(cb->flags&TCP_FIN)) {
               // log(DEBUG,"FIN_WAIT_1");
               // tsk->snd_una = cb->ack;
               //tsk->rcv_nxt = cb->seq_end;
                tcp_update_window_safe(tsk, cb);
                tcp_update_send_buffer(tsk, cb->ack);
                tcp_set_state(tsk, TCP_FIN_WAIT_2);
                wake_up(tsk->wait_send);
            }
            else if(cb->flags &(TCP_ACK | TCP_FIN)){
                //log(DEBUG,"double");
                //tsk->snd_una = cb->ack;
                //tsk->rcv_nxt = cb->seq_end;
                tcp_update_window_safe(tsk, cb);
                tcp_update_send_buffer(tsk, cb->ack);
                //tcp_update_retrans_timer(tsk);
              //  tcp_unset_retrans_timer(tsk);
                tcp_set_state(tsk, TCP_FIN_WAIT_2);
                tcp_set_state(tsk, TCP_TIME_WAIT);
                tcp_send_control_packet(tsk, TCP_ACK);
               // log(DEBUG,"create_timer from double");
                tcp_set_timewait_timer(tsk);
                wake_up(tsk->wait_send);
            }

            break;
        case TCP_TIME_WAIT:
            if (cb->flags & TCP_FIN&&!(cb->flags&TCP_ACK)) {
                tsk->rcv_nxt = cb->seq_end;
                tcp_send_control_packet(tsk, TCP_ACK);
               // log(DEBUG,"create_timer from TCP_TINE_WAIT");
                tcp_set_timewait_timer(tsk);
                tcp_unset_retrans_timer(tsk);
               // tcp_unset_retrans_timer(tsk);
                wake_up(tsk->wait_send);
            }
            break;
        default:
            break;
    }
}
   
    //log(DEBUG,"process unlock start");
    pthread_mutex_unlock(&tsk->sk_lock);
    //log(DEBUG,"process unlock success");
	//fprintf(stdout, "TODO: implement %s please.\n", __FUNCTION__);
}

int tcp_recv_ofo_buffer_add_packet(struct tcp_sock *tsk, struct tcp_cb *cb)
{
   
    pthread_mutex_lock(&tsk->rcv_buf_lock);
    if (less_or_equal_32b(cb->seq_end, tsk->rcv_nxt)) {
        // 这是一个重复的包，直接丢弃
        pthread_mutex_unlock(&tsk->rcv_buf_lock);
       // printf("duplicate packet: seq_end=%u, rcv_nxt=%u\n", cb->seq_end, tsk->rcv_nxt);
        return -1;
    }
    // 创建新的队列项
    struct recv_ofo_buf_entry *entry = malloc(sizeof(struct recv_ofo_buf_entry));
    entry->data = malloc(cb->pl_len);
    memcpy(entry->data, cb->payload, cb->pl_len);
    entry->len = cb->pl_len;
    entry->seq = cb->seq;
    entry->seq_end = cb->seq_end;
   // printf("seq_end=%u seq=%u\n",entry->seq_end,entry->seq);
    // 遍历乱序队列找到合适的位置插入
    struct recv_ofo_buf_entry *pos, *q;
    list_for_each_entry_safe(pos, q, &tsk->rcv_ofo_buf, list) {
        // 检查是否有重复数据
        if (entry->seq_end <= pos->seq_end && entry->seq >= pos->seq) {
            free(entry->data);
            free(entry);
           // printf("duplicate\n");
            pthread_mutex_unlock(&tsk->rcv_buf_lock);
            return -1;
        }
        
        // 找到合适的插入位置
        if (entry->seq < pos->seq) {
          //  printf("find_place_to_insert\n");
            list_add_tail(&entry->list, &pos->list);
            break;
        }
    }
    
    // 如果遍历完还没插入，则添加到末尾
    if (pos == list_entry(&tsk->rcv_ofo_buf, struct recv_ofo_buf_entry, list)) {
       // printf("add_to_last\n");
        list_add_tail(&entry->list, &tsk->rcv_ofo_buf);
    }

    // 尝试上送数据
   // log(DEBUG,"try_to_move");
    tcp_move_recv_ofo_buffer(tsk);
    
    pthread_mutex_unlock(&tsk->rcv_buf_lock);
    return 0;
}

int tcp_move_recv_ofo_buffer(struct tcp_sock *tsk)
{
    struct recv_ofo_buf_entry *entry, *q;
    int moved = 0;
    
    list_for_each_entry_safe(entry, q, &tsk->rcv_ofo_buf, list) {
        // 检查是否有序
       // printf("entry->seq=%u tsk->rcv_nxt=%u\n",entry->seq,tsk->rcv_nxt);
        if (entry->seq == tsk->rcv_nxt) {
            // 检查接收缓冲区是否有空间
            if (ring_buffer_free(tsk->rcv_buf) < entry->len) {
              //  log(DEBUG,"nospace");
                break;
            }
            
            // 写入接收缓冲区
           // log(DEBUG,"write_ring_buffer");
            write_ring_buffer(tsk->rcv_buf, entry->data, entry->len);
            tsk->rcv_nxt = entry->seq_end;
            
            // 更新接收窗口
            tsk->rcv_wnd = ring_buffer_free(tsk->rcv_buf);
            
            // 从乱序队列中移除
            list_delete_entry(&entry->list);
            free(entry->data);
            free(entry);
            
            moved = 1;
        } else {
            //log(DEBUG,"no_seq");
            break;  // 遇到乱序报文就退出
        }
    }

    if (moved) {
        wake_up(tsk->wait_recv);
    }
   // log(DEBUG,"moved=%d",moved);
    return moved;
}