#include "tcp_sock.h"

#include "log.h"
#include<string.h>
#include <unistd.h>
#define DATA "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
// tcp server application, listens to port (specified by arg) and serves only one
// connection request
void *tcp_server(void *arg)
{
	u16 port = *(u16 *)arg;
	struct tcp_sock *tsk = alloc_tcp_sock();

	struct sock_addr addr;
	addr.ip = htonl(0);
	addr.port = port;
	if (tcp_sock_bind(tsk, &addr) < 0) {
		log(ERROR, "tcp_sock bind to port %hu failed", ntohs(port));
		exit(1);
	}

	if (tcp_sock_listen(tsk, 3) < 0) {
		log(ERROR, "tcp_sock listen failed");
		exit(1);
	}

	log(DEBUG, "listen to port %hu.", ntohs(port));

	struct tcp_sock *csk = tcp_sock_accept(tsk);

	log(DEBUG, "accept a connection.");
    char buf[1000];
    while (1) {
        int len = tcp_sock_read(csk, buf, sizeof(buf));
        if (len <= 0) {
            break;
        }
        
        // 确保字符串以null结尾
        buf[len] = '\0';
        
        // 准备回复消息
        char response[1040];
        snprintf(response, sizeof(response), "server echoes: %s", buf);
        
        // 发送回复
        tcp_sock_write(csk, response, strlen(response));
    }

	//sleep(5);
   // log(DEBUG,"server_close");
	tcp_sock_close(csk);
	//log(DEBUG,"close succeed");
	return NULL;
}

// tcp client application, connects to server (ip:port specified by arg), each
// time sends one bulk of data and receives one bulk of data 
void *tcp_client(void *arg)
{
	struct sock_addr *skaddr = arg;

	struct tcp_sock *tsk = alloc_tcp_sock();

	if (tcp_sock_connect(tsk, skaddr) < 0) {
		log(ERROR, "tcp_sock connect to server ("IP_FMT":%hu)failed.", \
				NET_IP_FMT_STR(skaddr->ip), ntohs(skaddr->port));
		exit(1);
	}
	log(DEBUG,"tcp_sock connect to server ("IP_FMT":%hu) succeeded.", \
			NET_IP_FMT_STR(skaddr->ip), ntohs(skaddr->port));//自己加的
	 // 发送至少5次循环
	 for (int i = 0; i < 10; i++) {
        // 构造要发送的数据: 从DATA[i]开始的所有字符加上从DATA开始到DATA[i]的字符
        char send_buf[128];
        strcpy(send_buf, DATA + i);
        strncat(send_buf, DATA, i);
        
        // 发送数据
        tcp_sock_write(tsk, send_buf, strlen(send_buf));
       // log(DEBUG,"send data");
        // 接收服务器的回复
        char recv_buf[1000];
        int len = tcp_sock_read(tsk, recv_buf, sizeof(recv_buf));
		//log(DEBUG,"recv data");
	   // fprintf(stdout, "client len: %d\n", len);
        if (len > 0) {
            recv_buf[len] = '\0';
            fprintf(stdout, "%s\n", recv_buf);
        }
        
        sleep(1);
    }
   log(DEBUG,"close");
	tcp_sock_close(tsk);
	//log(DEBUG,"tcp_sock close succeeded");//my
   // log(DEBUG,"close succeed");
	return NULL;
}
