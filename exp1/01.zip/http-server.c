#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#define HTTP_PORT 80//http端口
#define HTTPS_PORT 443//https端口
#define BUFFER_SIZE 1024//报文缓冲区大小
void *handle_http(void *arg);//处理http请求
void *handle_https(void *arg);//处理https请求
void send_response(int client_socket, int status, const char *body, const char *location);//发送http响应
void send_https_file_response(SSL *ssl, const char *filepath, int start, int end,int is_partial);//发送https响应
int main() {
    pthread_t http_thread, https_thread;
    pthread_create(&http_thread, NULL, handle_http, NULL);//http线程
    pthread_create(&https_thread, NULL, handle_https, NULL);//https线程
    //等待两个线程结束
    pthread_join(http_thread, NULL);
    pthread_join(https_thread, NULL);
    return 0;
}

// 处理 HTTP 请求
void *handle_http(void *arg) {
    int server_socket, client_socket;//服务器套接字和客户端套接字
    struct sockaddr_in server_addr, client_addr;//服务器地址和客户端地址
    socklen_t client_len = sizeof(client_addr);//客户端地址长度
    char buffer[BUFFER_SIZE];//报文缓冲区
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {//创建套接字失败
        perror("HTTP socket creation failed");
        pthread_exit(NULL);
    }
    server_addr.sin_family = AF_INET;//协议族
    server_addr.sin_port = htons(HTTP_PORT);// 端口号,转网络字节序
    server_addr.sin_addr.s_addr = INADDR_ANY;//ip地址
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {//绑定套接字
        perror("HTTP bind failed");
        close(server_socket);
        pthread_exit(NULL);
    }
    if (listen(server_socket, 10) < 0) {//监听套接字，长度随便设的
        perror("HTTP listen failed");
        close(server_socket);
        pthread_exit(NULL);
    }
    while (1) {//循环处理请求
        client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &client_len);
        if (client_socket < 0) {
            perror("HTTP accept failed");
            continue;
        }
        read(client_socket, buffer, sizeof(buffer));//读取请求报文，写入缓冲区
        char method[16], path[256], protocol[16];//请求方法（GET），路径，协议（HTTP/HTTPS）
        sscanf(buffer, "%s %s %s", method, path, protocol);
        //处理301 re-direction
        if (strcmp(method, "GET") == 0&&strcmp(path,"/index.html")==0) {
            send_response(client_socket, 301, NULL, "https://10.0.0.1/index.html");

        
        }
        //处理文件
        else if(strcmp(method, "GET") == 0&&strcmp(path,"/dir/index.html")==0){
            send_response(client_socket, 301, NULL, "https://10.0.0.1/dir/index.html");
        }
        //处理404 Not Found
        else {
            send_response(client_socket, 404, "<html><body><h1>404 Not Found</h1></body></html>", NULL);
        }
        close(client_socket);
    }
}

// 处理 HTTPS 请求
void *handle_https(void *arg) {
    // 初始化 SSL 库
    SSL_library_init();
    OpenSSL_add_all_algorithms();
    SSL_load_error_strings();
    //加载证书和私钥
    const SSL_METHOD *method = TLS_server_method();
    SSL_CTX *ctx = SSL_CTX_new(method);
    if (SSL_CTX_use_certificate_file(ctx, "./keys/cnlab.cert", SSL_FILETYPE_PEM) <= 0) {
        perror("Load cert failed");
        exit(1);
    }
    if (SSL_CTX_use_PrivateKey_file(ctx, "./keys/cnlab.prikey", SSL_FILETYPE_PEM) <= 0) {
        perror("Load prikey failed");
        exit(1);
    }
    int server_socket = socket(AF_INET, SOCK_STREAM, 0);//创建套接字
    if (server_socket < 0) {
        perror("HTTPS socket creation failed");
        exit(1);
    }
    int enable = 1;
    if (setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0) {//设置套接字选项
        perror("setsockopt(SO_REUSEADDR) failed");
        exit(1);
    }
    struct sockaddr_in server_addr;//服务器地址
    bzero(&server_addr, sizeof(server_addr));//清零初始化
    server_addr.sin_family = AF_INET;//协议族
    server_addr.sin_port = htons(HTTPS_PORT);//端口号
    server_addr.sin_addr.s_addr = INADDR_ANY;//ip地址
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {//绑定套接字
        perror("HTTPS bind failed");
        exit(1);
    }
    if (listen(server_socket, 10) < 0) {//监听套接字
        perror("HTTPS listen failed");
        exit(1);
    }
    while (1) {//循环处理请求
        struct sockaddr_in client_addr;//客户端地址
        socklen_t client_len = sizeof(client_addr);//客户端地址长度
        int client_sock = accept(server_socket, (struct sockaddr *)&client_addr, &client_len);
        if (client_sock < 0) {
            perror("HTTPS accept failed");
            continue;
        }
        //创建SSL对象
        SSL *ssl = SSL_new(ctx);
        SSL_set_fd(ssl, client_sock);
        if (SSL_accept(ssl) <= 0) {
            ERR_print_errors_fp(stderr);
        } else {
            char buffer[BUFFER_SIZE];
            SSL_read(ssl, buffer, sizeof(buffer));//读取请求报文
            // 解析请求行
            char method[16], path[256], protocol[16];//请求方法（GET），路径，协议（HTTP/HTTPS）
            sscanf(buffer, "%s %s %s", method, path, protocol);
            // 处理 200 OK
            if (strcmp(method, "GET") == 0&&strstr(buffer, "Range: bytes=")==NULL) {
                send_https_file_response(ssl, path + 1, -1, -1,0);//发送完整文件

            // 处理 206 Partial Content
            } else if (strstr(buffer, "Range: bytes=")) {
                int start = 0, end = -1;
                sscanf(strstr(buffer, "Range: bytes=") + 13, "%d-%d", &start, &end);
                send_https_file_response(ssl, path + 1, start, end,1);//发送部分文件

            // 处理 404 Not Found
            } else {
                SSL_write(ssl, "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n", 47);//发送404响应
            }
        }
       //关闭SSL连接
        SSL_shutdown(ssl);
        SSL_free(ssl);
        close(client_sock);
    }
    //关闭套接字和SSL上下文
    close(server_socket);
    SSL_CTX_free(ctx);
}

// 发送 HTTP 响应
void send_response(int client_socket, int status, const char *body, const char *location) {//body为响应体(test里没考虑)，location为重定向地址
    char response[BUFFER_SIZE];//响应报文
    if (status == 301) {
        snprintf(response, sizeof(response),
                 "HTTP/1.1 301 Moved Permanently\r\n"
                 "Location: %s\r\n"//重定向到location
                 "Content-Length: 0\r\n\r\n",
                 location);
    } 
    else if (status == 404) {
        snprintf(response, sizeof(response),
                 "HTTP/1.1 404 Not Found\r\n"
                 "Content-Type: text/html\r\n"
                 "Content-Length: %lu\r\n\r\n"
                 "%s",
                 strlen(body), body);
    }
    write(client_socket, response, strlen(response));//发送响应
}


// 发送 HTTPS 200 OK 或 206 Partial Content 或 404 Not Found
void send_https_file_response(SSL *ssl, const char *filepath, int start, int end, int is_partial) {
    FILE *file = fopen(filepath, "rb");//打开文件
    if (!file) {//文件不存在，发送404响应
        SSL_write(ssl, "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n", 47);
        return;
    }
    fseek(file, 0, SEEK_END);
    int file_size = ftell(file);//文件大小
    rewind(file);//文件指针重置
    if (start == -1) {  // 处理普通 GET 请求（返回完整文件）
        start = 0;
        end = file_size - 1;
    }
    if (end == -1 || end >= file_size) {  // 处理 "Range: bytes=x-" 情况
        end = file_size - 1;
    }
    int content_length = end - start + 1;//内容长度
    char *content = malloc(content_length);//内容缓冲区
    fseek(file, start, SEEK_SET);//移动文件指针
    fread(content, 1, content_length, file);//读取文件内容
    fclose(file);
    char response[BUFFER_SIZE];//响应报文
    if (is_partial) {//206
        snprintf(response, sizeof(response),
                 "HTTP/1.1 206 Partial Content\r\n"
                 "Content-Type: text/html\r\n"
                 "Content-Range: bytes %d-%d/%d\r\n"
                 "Content-Length: %d\r\n\r\n",
                 start, end, file_size, content_length);
    } else {//200
        snprintf(response, sizeof(response),
                 "HTTP/1.1 200 OK\r\n"
                 "Content-Type: text/html\r\n"
                 "Content-Length: %d\r\n\r\n",
                 content_length);
    }
    //发送响应
    SSL_write(ssl, response, strlen(response));
    SSL_write(ssl, content, content_length);
    free(content);
}