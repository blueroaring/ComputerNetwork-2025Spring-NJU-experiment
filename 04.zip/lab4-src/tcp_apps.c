#include "tcp_sock.h"

#include "log.h"
#include<string.h>
#include <unistd.h>
//#define DATA "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
// tcp server application, listens to port (specified by arg) and serves only one
// connection request
void *tcp_server(void *arg)
{
	u16 port = *(u16 *)arg;
	struct tcp_sock *tsk = alloc_tcp_sock();

	struct sock_addr addr;
	addr.ip = htonl(0);
	addr.port = port;
	if (tcp_sock_bind(tsk, &addr) < 0) {
		log(ERROR, "tcp_sock bind to port %hu failed", ntohs(port));
		exit(1);
	}

	if (tcp_sock_listen(tsk, 3) < 0) {
		log(ERROR, "tcp_sock listen failed");
		exit(1);
	}

	log(DEBUG, "listen to port %hu.", ntohs(port));

	struct tcp_sock *csk = tcp_sock_accept(tsk);

	log(DEBUG, "accept a connection.");
   /* char buf[1000];
    while (1) {
        int len = tcp_sock_read(csk, buf, sizeof(buf));
        if (len <= 0) {
            break;
        }
        
        // 确保字符串以null结尾
        buf[len] = '\0';
        
        // 准备回复消息
        char response[1040];
        snprintf(response, sizeof(response), "server echoes: %s", buf);
        
        // 发送回复
        tcp_sock_write(csk, response, strlen(response));
    }*/

   
   /*while (1) {
	   // 确保在关闭连接前读取所有数据
	   pthread_mutex_lock(&csk->rcv_buf_lock);
	   int available = ring_buffer_used(csk->rcv_buf);
	   pthread_mutex_unlock(&csk->rcv_buf_lock);

	   int len = tcp_sock_read(csk, buf, sizeof(buf));
	   
	   if (len > 0) {
		   fwrite(buf, 1, len, fp);
		   total_received += len;
		   fflush(fp);  // 确保数据写入磁盘
	   } 
	   else if (len == 0 && available == 0) {
		   // 只有当接收缓冲区为空且返回0时才退出
		   break;
	   }
	   // 如果len < 0，继续尝试读取
   }
   log(DEBUG, "Server received total %d bytes", total_received);
    
   // 确保所有数据写入磁盘
   fflush(fp);*/
   FILE *fp = fopen("server-output.dat", "w");
   if (!fp) {
       log(ERROR, "failed to open server-output.dat");
       exit(1);
   }

   char buf[1024];
   int total_received = 0;

   while (1) {
       pthread_mutex_lock(&csk->rcv_buf_lock);
       
       // 检查接收缓冲区和乱序队列
       int available = ring_buffer_used(csk->rcv_buf);
       int ofo_available = 0;
       struct recv_ofo_buf_entry *entry;
       list_for_each_entry(entry, &csk->rcv_ofo_buf, list) {
           ofo_available += entry->len;
       }
      // log(DEBUG,"csk->state=%u",csk->state);
       // 如果连接已关闭且无数据可读，则退出
       if ((csk->state == TCP_CLOSE_WAIT || csk->state == TCP_CLOSED) && 
           available == 0 && ofo_available == 0) {
           pthread_mutex_unlock(&csk->rcv_buf_lock);
           break;
       }
       pthread_mutex_unlock(&csk->rcv_buf_lock);
      // log(DEBUG,"read");
       // 尝试读取数据
       int len = tcp_sock_read(csk, buf, sizeof(buf));
       if (len > 0) {
           size_t written = fwrite(buf, 1, len, fp);
           if (written != len) {
               log(ERROR, "Failed to write all data to file");
               break;
           }
           total_received += len;
           
           // 立即刷新文件缓冲区
           if (fflush(fp) != 0) {
               log(ERROR, "Failed to flush file buffer");
               break;
           }
       } 
       else if (len < 0) {
           // 如果读取失败，等待一下再继续
           usleep(1000);
           continue;
       }
   }

   log(DEBUG, "Server received total %d bytes", total_received);

   // 确保所有数据写入磁盘
   fflush(fp);
   fclose(fp);

   // 给一些时间让其他操作完成
   sleep(1);
   // log(DEBUG,"server_close");
	tcp_sock_close(csk);
	//log(DEBUG,"close succeed");
	return NULL;
}

// tcp client application, connects to server (ip:port specified by arg), each
// time sends one bulk of data and receives one bulk of data 
void *tcp_client(void *arg)
{
	struct sock_addr *skaddr = arg;

	struct tcp_sock *tsk = alloc_tcp_sock();

	if (tcp_sock_connect(tsk, skaddr) < 0) {
		log(ERROR, "tcp_sock connect to server ("IP_FMT":%hu)failed.", \
				NET_IP_FMT_STR(skaddr->ip), ntohs(skaddr->port));
		exit(1);
	}
	log(DEBUG,"tcp_sock connect to server ("IP_FMT":%hu) succeeded.", \
			NET_IP_FMT_STR(skaddr->ip), ntohs(skaddr->port));//自己加的
	 // 发送至少5次循环
	/* for (int i = 0; i < 10; i++) {
        // 构造要发送的数据: 从DATA[i]开始的所有字符加上从DATA开始到DATA[i]的字符
        char send_buf[128];
        strcpy(send_buf, DATA + i);
        strncat(send_buf, DATA, i);
        
        // 发送数据
        tcp_sock_write(tsk, send_buf, strlen(send_buf));
       // log(DEBUG,"send data");
        // 接收服务器的回复
        char recv_buf[1000];
        int len = tcp_sock_read(tsk, recv_buf, sizeof(recv_buf));
		//log(DEBUG,"recv data");
	   // fprintf(stdout, "client len: %d\n", len);
        if (len > 0) {
            recv_buf[len] = '\0';
            fprintf(stdout, "%s\n", recv_buf);
        }
        
        sleep(1);
    }*/
   log(DEBUG,"open file");
	FILE *fp = fopen("client-input.dat", "r");
    if (!fp) {
        log(ERROR, "failed to open client-input.dat");
        exit(1);
    }
   log(DEBUG,"start send file");
    // 读取文件并发送数据
    char buf[1024];
    size_t read_len;
    while ((read_len = fread(buf, 1, sizeof(buf), fp)) > 0) {
        int sent_len = tcp_sock_write(tsk, buf, read_len);
        if (sent_len < 0) {
            log(ERROR, "tcp_sock_write failed");
            break;
        }
    }

    // 关闭文件和连接
    fclose(fp);
    pthread_mutex_lock(&tsk->send_buf_lock);
    while (!list_empty(&tsk->send_buf)) {
        pthread_mutex_unlock(&tsk->send_buf_lock);
        sleep_on(tsk->wait_send);
        pthread_mutex_lock(&tsk->send_buf_lock);
    }
    pthread_mutex_unlock(&tsk->send_buf_lock);
   // sleep(1);  // 等待数据发送完成
   //log(DEBUG,"close");
	tcp_sock_close(tsk);
	//log(DEBUG,"tcp_sock close succeeded");//my
   // log(DEBUG,"close succeed");
	return NULL;
}
