#include "tcp.h"
#include "tcp_timer.h"
#include "tcp_sock.h"

#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

#include "log.h"

static struct list_head timer_list = {&timer_list, &timer_list};
static pthread_mutex_t timer_list_lock= PTHREAD_MUTEX_INITIALIZER;
static void tcp_init_hdr(struct tcphdr *tcp, u16 sport, u16 dport, u32 seq, u32 ack,
    u8 flags, u16 rwnd)
{
memset((char *)tcp, 0, TCP_BASE_HDR_SIZE);

tcp->sport = htons(sport);
tcp->dport = htons(dport);
tcp->seq = htonl(seq);
tcp->ack = htonl(ack);
tcp->off = TCP_HDR_OFFSET;
tcp->flags = flags;
tcp->rwnd = htons(rwnd);
}
// scan the timer_list, find the tcp sock which stays for at 2*MSL, release it
void tcp_scan_timer_list()
{
    pthread_mutex_lock(&timer_list_lock);
    struct tcp_timer *timer, *q;
    list_for_each_entry_safe(timer, q, &timer_list, list) {
        if (timer->enable && timer->timeout <= 0) {
            if (timer->type == 0) {  // TIME_WAIT timer
                struct tcp_sock *tsk = timewait_to_tcp_sock(timer);
                if (tsk->state == TCP_TIME_WAIT) {
                    tcp_set_state(tsk, TCP_CLOSED);
                    list_delete_entry(&timer->list);
                    timer->enable = 0;
                   // log(DEBUG,"time wait timer");
                    free_tcp_sock(tsk);
                }
            }
            else if (timer->type == 2) { // persist timer
                struct tcp_sock *tsk = persisttimer_to_tcp_sock(timer);
                if (tsk->state != TCP_CLOSED && tsk->snd_wnd < TCP_MSS&&!tsk->parent) {
                    tcp_send_probe_packet(tsk);
                    timer->timeout = TCP_PERSIST_INTERVAL_INITIAL;
                } else {
                    tcp_unset_persist_timer(tsk);
                }
            }
            else if(timer->type==1){
                struct tcp_sock *tsk = retranstimer_to_tcp_sock(timer);
                if (tsk->state != TCP_CLOSED) {
                    if (timer->retrans_times >= TCP_RETRANS_MAX_TIMES) {
                        // 达到重传上限,强制关闭连接
                        tcp_send_reset(tsk);
                        tcp_unhash(tsk);
                        wake_up(tsk->wait_connect);
                        wake_up(tsk->wait_accept); 
                        wake_up(tsk->wait_recv);
                        wake_up(tsk->wait_send);
                    } else {
                        // 执行重传
                      //  log(DEBUG,"do retrans");
                      /*  pthread_mutex_lock(&tsk->sk_lock);
                        tsk->c_state=TCP_CONG_LOSS;
                        tsk->ssthresh = tsk->cwnd / 2;
                        tsk->cwnd = 1;
                        pthread_mutex_unlock(&tsk->sk_lock);*/
                        tsk->c_state=TCP_CONG_LOSS;
                        tcp_retrans_send_buffer(tsk);
                        timer->retrans_times++;
                        timer->timeout = TCP_RETRANS_INTERVAL_INITIAL << timer->retrans_times;
                    }
                }
            }
            // ... handle other timer types
        } else {
            timer->timeout -= TCP_TIMER_SCAN_INTERVAL;
        }
    }
    pthread_mutex_unlock(&timer_list_lock);
}

// set the timewait timer of a tcp sock, by adding the timer into timer_list
void tcp_set_timewait_timer(struct tcp_sock *tsk)
{
	tsk->timewait.type = 0;
    tsk->timewait.timeout = TCP_TIMEWAIT_TIMEOUT;
    tsk->timewait.enable = 1;
    list_add_tail(&tsk->timewait.list, &timer_list);
	//fprintf(stdout, "TODO: implement %s please.\n", __FUNCTION__);
}

// scan the timer_list periodically by calling tcp_scan_timer_list
void *tcp_timer_thread(void *arg)
{
	init_list_head(&timer_list);
	while (1) {
		usleep(TCP_TIMER_SCAN_INTERVAL);
		tcp_scan_timer_list();
	}

	return NULL;
}
void tcp_set_persist_timer(struct tcp_sock *tsk) 
{
    pthread_mutex_lock(&timer_list_lock);
    if (tsk->persist_timer.enable) {
        pthread_mutex_unlock(&timer_list_lock);
        return;
    }

    tsk->persist_timer.type = 2;
    tsk->persist_timer.timeout = TCP_PERSIST_INTERVAL_INITIAL;
    tsk->persist_timer.enable = 1;
    
    tsk->ref_cnt += 1;
    list_add_tail(&tsk->persist_timer.list, &timer_list);
    pthread_mutex_unlock(&timer_list_lock);
}
void tcp_unset_persist_timer(struct tcp_sock *tsk)
{
    pthread_mutex_lock(&timer_list_lock);
    if (!tsk->persist_timer.enable) {
        pthread_mutex_unlock(&timer_list_lock);
        return;
    }

    tsk->persist_timer.enable = 0;
    list_delete_entry(&tsk->persist_timer.list);
    free_tcp_sock(tsk);
    pthread_mutex_unlock(&timer_list_lock);
}

void tcp_set_retrans_timer(struct tcp_sock *tsk)
{
    pthread_mutex_lock(&timer_list_lock);
    if (tsk->retrans_timer.enable) {
        // 已启用则只更新超时时间
        tsk->retrans_timer.timeout = TCP_RETRANS_INTERVAL_INITIAL;
        pthread_mutex_unlock(&timer_list_lock);
        return;
    }
   // log(DEBUG,"create");
    // 创建新的重传定时器
    tsk->retrans_timer.type = 1;
    tsk->retrans_timer.timeout = TCP_RETRANS_INTERVAL_INITIAL;
    tsk->retrans_timer.enable = 1;
    tsk->retrans_timer.retrans_times = 0;
    
    // 增加引用计数并加入定时器列表
    tsk->ref_cnt += 1;
    list_add_tail(&tsk->retrans_timer.list, &timer_list);
   // log(DEBUG,"set_retrans_timer");
    pthread_mutex_unlock(&timer_list_lock);
}

void tcp_unset_retrans_timer(struct tcp_sock *tsk)
{
    pthread_mutex_lock(&timer_list_lock);
    if (!tsk->retrans_timer.enable) {
       // log(DEBUG,"nothing");
        pthread_mutex_unlock(&timer_list_lock);
        return;
    }
   // log(DEBUG,"unset_retrans_timer");
    tsk->retrans_timer.enable = 0;
    list_delete_entry(&tsk->retrans_timer.list);
    free_tcp_sock(tsk);
    pthread_mutex_unlock(&timer_list_lock);
}

void tcp_update_retrans_timer(struct tcp_sock *tsk)
{
    pthread_mutex_lock(&timer_list_lock);
    if (!tsk->retrans_timer.enable) {
        pthread_mutex_unlock(&timer_list_lock);
        return;
    }

    pthread_mutex_lock(&tsk->send_buf_lock);
    if (list_empty(&tsk->send_buf)) {
        // 发送队列为空,删除定时器
        tcp_unset_retrans_timer(tsk);
        wake_up(tsk->wait_send);
    } else {
        // 重置定时器状态
        tsk->retrans_timer.timeout = TCP_RETRANS_INTERVAL_INITIAL;
        tsk->retrans_timer.retrans_times = 0;
    }
    pthread_mutex_unlock(&tsk->send_buf_lock);
    
    pthread_mutex_unlock(&timer_list_lock);
}


void tcp_send_probe_packet(struct tcp_sock *tsk)
{
    log(DEBUG,"send probe");
    int pkt_size = ETHER_HDR_SIZE + IP_BASE_HDR_SIZE + TCP_BASE_HDR_SIZE + 1;
    char *packet = malloc(pkt_size);
    if (!packet) {
        log(ERROR, "Failed to allocate probe packet");
        return;
    }

    struct iphdr *ip = packet_to_ip_hdr(packet);
    ip_init_hdr(ip, tsk->sk_sip, tsk->sk_dip, 
                IP_BASE_HDR_SIZE + TCP_BASE_HDR_SIZE + 1, IPPROTO_TCP);

    struct tcphdr *tcp = (struct tcphdr *)((char *)ip + IP_BASE_HDR_SIZE);
    tcp_init_hdr(tcp, tsk->sk_sport, tsk->sk_dport, 
                 tsk->snd_una - 1,  // 探测包序列号 = snd_una - 1（避免影响正常数据）
                 tsk->rcv_nxt,       // ACK 号不变
                 TCP_ACK,            // 仅设置 ACK 标志
                 tsk->rcv_wnd);      // 当前接收窗口

    char probe_byte = 0;
    memcpy((char *)tcp + TCP_BASE_HDR_SIZE, &probe_byte, 1);
    tcp->checksum = tcp_checksum(ip, tcp);
    ip_send_packet(packet, pkt_size);

    //log(DEBUG, "Sent window probe: seq=%u, ack=%u", 
        //tsk->snd_una - 1, tsk->rcv_nxt);
}