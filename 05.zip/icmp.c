#include "icmp.h"
#include "ip.h"
#include "rtable.h"
#include "arp.h"
#include "base.h"
#include "log.h"
#include <stdlib.h>
#include <assert.h>

// icmp_send_packet has two main functions:
// 1.handle icmp packets sent to the router itself (ICMP ECHO REPLY).
// 2.when an error occurs, send icmp error packets.
// Note that the structure of these two icmp packets is different, you need to malloc different sizes of memory.
// Some function and macro definitions in ip.h/icmp.h can help you.
void icmp_send_packet(const char *in_pkt, int len, u8 type, u8 code)
{
    log(DEBUG, "Sending ICMP packet, type: %d, code: %d\n", type, code);
	struct iphdr *in_ip=packet_to_ip_hdr(in_pkt);
	int icmp_len;
	char *packet;

	if(type==ICMP_ECHOREPLY){
		icmp_len=len-ETHER_HDR_SIZE-IP_BASE_HDR_SIZE;
        packet=malloc(ETHER_HDR_SIZE+IP_BASE_HDR_SIZE+icmp_len);
	}
	else{
		icmp_len=ICMP_HDR_SIZE +IP_BASE_HDR_SIZE+ ICMP_COPIED_DATA_LEN;
		packet=malloc(ETHER_HDR_SIZE+IP_BASE_HDR_SIZE+icmp_len);
	}

	// 设置以太网头部
    struct ether_header *eh = (struct ether_header *)packet;
    eh->ether_type = htons(ETH_P_IP);
    // MAC地址将在 ip_send_packet 中通过 ARP 设置
    
    rt_entry_t *rt_entry = longest_prefix_match(ntohl(in_ip->saddr));
    if (!rt_entry) {
        free(packet);
        return;
    }

    struct iphdr *ip=packet_to_ip_hdr(packet);
	ip_init_hdr(ip, rt_entry->iface->ip, ntohl(in_ip->saddr), 
                IP_BASE_HDR_SIZE + icmp_len, IPPROTO_ICMP);


    struct icmphdr *icmp = (struct icmphdr *)IP_DATA(ip);
	memset(icmp, 0, sizeof(struct icmphdr));
    icmp->type = type;
    icmp->code = code;
    icmp->checksum = 0;
    
    if (type == ICMP_ECHOREPLY) {
        // 对于 ECHO REPLY，复制原始 ICMP 数据包的内容
        struct icmphdr *in_icmp = (struct icmphdr *)IP_DATA(in_ip);
        memcpy(icmp, in_icmp, icmp_len);
        icmp->type = ICMP_ECHOREPLY;
        icmp->code = 0;
        // 重要：保持 id 和 sequence 与请求包相同
      //  icmp->icmp_identifier = in_icmp->icmp_identifier;
       // icmp->icmp_sequence = in_icmp->icmp_sequence;
    } else {
        // 对于错误消息，复制原始 IP 头和部分数据
        memcpy((char *)icmp + ICMP_HDR_SIZE, in_ip, IP_BASE_HDR_SIZE + ICMP_COPIED_DATA_LEN);
        // 对于错误消息，unused 字段应该设置为 0
        icmp->icmp_identifier = 0;
        icmp->icmp_sequence = 0;
    }
	icmp->checksum=icmp_checksum(icmp,icmp_len);
	ip_send_packet(packet,ETHER_HDR_SIZE+IP_BASE_HDR_SIZE+icmp_len);
	//assert(0 && "TODO: function icmp_send_packet not implemented!");
}
